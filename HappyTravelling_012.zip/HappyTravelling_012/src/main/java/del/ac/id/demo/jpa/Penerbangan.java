package del.ac.id.demo.jpa;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "t_penerbangan")
public class Penerbangan {
	@Id
	@Column(name="Dari")
	private String from;
	@Column(name="Ke")
	private String to;
	@Column(name="Nomor")
	private int noPassenger;
	@Column(name="Departure")
	private Date departureDate;
	@Column(name="Kembali")
	private Date returnDate;
	
	public Penerbangan() {}
	
	public Penerbangan(String from, String to, int noPassenger, Date departureDate, Date returnDate) {
		this.from = from;
		this.to = to;
		this.noPassenger = noPassenger;
		this.departureDate = departureDate;
		this.returnDate = returnDate;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public int getNoPassenger() {
		return noPassenger;
	}

	public void setNoPassenger(int noPassenger) {
		this.noPassenger = noPassenger;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}	
	
}
