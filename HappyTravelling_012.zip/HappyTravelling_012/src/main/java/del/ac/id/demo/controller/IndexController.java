package del.ac.id.demo.controller;

import java.awt.print.Pageable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import del.ac.id.demo.jpa.User;

public class IndexController {
	
	@Autowired
    private PenerbanganDao penerbanganDao;

    @GetMapping("/index")
    public ModelMap getAll(Pageable pageable) {
        return new ModelMap().addAttribute("penerbangans", penerbanganDao.findAll(pageable));
    }

	@GetMapping("/")
    public String index() {
        return "redirect:/index";
    }
	
	@GetMapping("/home")
	public ModelAndView home() {
		ModelAndView mv = new ModelAndView("home");
		mv.addObject("user", new User());
		return mv;
	}
}
