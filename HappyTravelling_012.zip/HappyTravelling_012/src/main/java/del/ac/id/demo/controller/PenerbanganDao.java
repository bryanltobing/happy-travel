package del.ac.id.demo.controller;

import java.awt.print.Pageable;

public class PenerbanganDao {

	public Object findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

}
